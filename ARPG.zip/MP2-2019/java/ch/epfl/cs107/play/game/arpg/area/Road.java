package ch.epfl.cs107.play.game.arpg.area;

public class Road {

}
